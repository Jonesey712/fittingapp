package com.monique.fittingapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FittingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FittingAppApplication.class, args);
	}

}
