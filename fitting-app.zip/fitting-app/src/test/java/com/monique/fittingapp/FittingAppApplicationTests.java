package com.monique.fittingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FittingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
